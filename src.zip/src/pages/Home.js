import React from 'react'
import Dashboard from '../components/Dashboard'
import Login from '../components/Auth/Login'

const Home = () => {
  return (
    <>
    <Dashboard />
    </>
  )
}

export default Home