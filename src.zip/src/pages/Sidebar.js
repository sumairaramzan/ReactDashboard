// Sidebar.js
import React from "react";
import { Link } from "react-router-dom";
import {
  FaTachometerAlt,
  FaUser,
  FaFilePrescription,
  FaQuestionCircle,
  FaConciergeBell,
  FaHeartbeat,
  FaMoneyBill,
  FaBook,
  FaFlask,
  FaBlog,
  FaEnvelope,
  FaTicketAlt,
  FaBell,
  FaCog,
  FaStar,
  FaCalendarAlt,
  FaAngleDown,
} from "react-icons/fa";

const sidebarItems = [
  { label: "Dashboard", icon: <FaTachometerAlt />, to: "#" },
  {
    label: "Patient",
    icon: <FaUser />,
    dropdown: [
      { label: "Patients List", to: "#" },
      { label: "Black list Patient", to: "#" },
    ],
  },
  { label: "Prescription", icon: <FaFilePrescription />, to: "#" },
  { label: "Intake Questions", icon: <FaQuestionCircle />, to: "#" },
  { label: "Services", icon: <FaConciergeBell />, to: "#" },
  { label: "Mood Checkup", icon: <FaHeartbeat />, to: "#" },
  { label: "Payments", icon: <FaMoneyBill />, to: "#" },
  { label: "Library", icon: <FaBook />, to: "#" },
  { label: "Laboratory Test", icon: <FaFlask />, to: "#" },
  { label: "Blogs", icon: <FaBlog />, to: "#" },
  { label: "Messages", icon: <FaEnvelope />, to: "#" },
  { label: "All Tickets", icon: <FaTicketAlt />, to: "#" },
  { label: "Notification", icon: <FaBell />, to: "#" },
  { label: "Settings", icon: <FaCog />, to: "#" },
  { label: "Review", icon: <FaStar />, to: "#" },
  { label: "Appointment", icon: <FaCalendarAlt />, to: "#" },
];

const Sidebar = ({ activeDropdown, toggleDropdown, sidebarOpen }) => {
    return (
      <div className={`sidebar bg-white shadow-sm ${sidebarOpen ? "show" : ""}`}>
        <h4 className="text-center py-3 border-bottom">
          <img src="../assets/logo.png" alt="Logo" className="logo" />
        </h4>
        <ul className="list-unstyled px-2">
          {sidebarItems.map((item, index) => (
            <li key={index}>
              <Link
                to={item.to}
                className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
                onClick={() =>
                  item.dropdown ? toggleDropdown(item.label) : null
                }
              >
                <span>
                  {item.icon} {item.label}
                </span>
                {item.dropdown && (
                  <FaAngleDown
                    className={`${
                      activeDropdown === item.label ? "rotate" : ""
                    }`}
                  />
                )}
              </Link>
  
              {item.dropdown && (
                <ul
                  className={`submenu list-unstyled ${
                    activeDropdown === item.label ? "show" : ""
                  }`}
                >
                  {item.dropdown.map((subItem, subIndex) => (
                    <li key={subIndex}>
                      <Link to={subItem.to} className="nav-link px-4 py-2">
                        {subItem.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </div>
    );
  };
  

export default Sidebar;
