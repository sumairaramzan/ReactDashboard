import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../App.css";
import {
  Navbar,
  Nav,
  Container,
  Row,
  Col,
  Table,
  Button,
  Form,
  InputGroup,
  Dropdown,
  Image,
} from "react-bootstrap";
import {
  FaTachometerAlt,
  FaUser,
  FaCalendarAlt,
  FaFilePrescription,
  FaConciergeBell,
  FaQuestionCircle,
  FaHeartbeat,
  FaBook,
  FaFlask,
  FaBlog,
  FaMoneyBill,
  FaEnvelope,
  FaTicketAlt,
  FaBell,
  FaCog,
  FaStar,
  FaAngleDown,
  FaSearch,
  FaPlus,
  FaEllipsisH,
  FaWhatsapp,
  FaHouseUser,
} from "react-icons/fa";
import SearchBar from "./SearchBar/SearchBar";
import profile from "../assets/Profile.png";
import logo from "../assets/logo2.png";
import { logout } from "../redux/slices/authSlice";
import { useDispatch } from "react-redux";

const Dashboard = () => {
  const [activeDropdown, setActiveDropdown] = useState("");

  const toggleDropdown = (menu) => {
    setActiveDropdown(activeDropdown === menu ? "" : menu);
  };

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  return (
    <div className="dashboard-container">
      <div className="sidebar bg-white shadow-sm">
        <h4 className=" py-3 ps-3">
          <img src={logo} alt="Logo" className="logo" />
        </h4>
        <ul className="list-unstyled px-2">
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaHouseUser className="me-2" /> Dashboard
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaUser className="me-2" /> Patient
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaFilePrescription className="me-2" /> Prescription
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaQuestionCircle className="me-2" /> Intake Questions
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaConciergeBell className="me-2" /> Services
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaHeartbeat className="me-2" /> Mood Checkup
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaMoneyBill className="me-2" />
                Payments
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaBook className="me-2" /> Library
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaFlask className="me-2" /> Laboratory Test
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaBlog className="me-2" /> Blogs
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaFilePrescription className="me-2" /> Prescription
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaEnvelope className="me-2" /> Messages
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaTicketAlt className="me-2" /> All Tickets
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaUser className="me-2" /> Doctor
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaBell className="me-2" /> Notification
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaCog className="me-2" /> Settings
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex justify-content-between align-items-center"
              onClick={() => toggleDropdown("patient")}
            >
              <span>
                <FaCalendarAlt className="me-2" /> Appointment
              </span>
              <FaAngleDown
                className={`${activeDropdown === "patient" ? "rotate" : ""}`}
              />
            </Link>
            <ul
              className={`submenu list-unstyled ${
                activeDropdown === "patient" ? "show" : ""
              }`}
            >
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Patients List
                </Link>
              </li>
              <li>
                <Link to="#" className="nav-link px-4 py-2">
                  Black list Patient
                </Link>
              </li>
            </ul>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaStar className="me-2" /> Review
            </Link>
          </li>
        </ul>
      </div>

      <div className="main-content">
        <Navbar bg="white" expand="lg" className="shadow-sm mb-4 rounded">
          <Container fluid>
            <Navbar.Brand>Hello, John Warker</Navbar.Brand>
            <SearchBar />
            <Nav className="align-items-center">
              <Nav.Link href="#" className="eng-link">
                ENG
              </Nav.Link>

              <Nav.Link
                href="#"
                className="notification-link position-relative"
              >
                <FaBell />
                <span className="notification-badge">3</span>
              </Nav.Link>
              <Nav.Link
                href="#"
                className="notification-link position-relative"
              >
                <FaWhatsapp />
                <span className="notification-badge">3</span>
              </Nav.Link>

              <Dropdown>
                <Dropdown.Toggle
                  as="div"
                  className="profile-toggle custom-toggle"
                >
                  <Image src={profile} roundedCircle className="profile-img" />
                  <div className="profile-info">
                    <span className="profile-name">John Warker</span>
                    <span className="role-badge">Admin</span>
                  </div>
                  <FaAngleDown className="dropdown-icon" />
                </Dropdown.Toggle>

                <Dropdown.Menu className="profile-dropdown">
                  <Dropdown.Item href="#">Profile</Dropdown.Item>
                  <Dropdown.Item href="#">Settings</Dropdown.Item>
                  <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </Nav>
          </Container>
        </Navbar>

        <Container fluid>
          <div className="d-flex justify-content-between mb-2">
            <h4 className="mb-4">Black List Patients</h4>
            <Button variant="dark" className="rounded ">
              <FaPlus /> Add Black Patient
            </Button>
          </div>
          <div className="bg-white p-3 rounded">
            <Row className="mb-3 align-items-center">
              {/* Filter By Label */}
              <Col xs="auto">
                <span className="filter-label">Filter by:</span>
              </Col>

              {/* ID Filter */}
              <Col xs="auto">
                <InputGroup className="filter-group">
                  <Form.Select className="bg-light filter-input">
                    <option>ID</option>
                    <option>Active</option>
                    <option>Black</option>
                  </Form.Select>
                </InputGroup>
              </Col>

              {/* Name Filter */}
              <Col xs="auto">
                <InputGroup className="filter-group">
                  <Form.Select className="bg-light  filter-input">
                    <option>Name</option>
                    <option>Active</option>
                    <option>Black</option>
                  </Form.Select>
                </InputGroup>
              </Col>

              {/* Status Filter */}
              <Col xs="auto">
                <InputGroup className="filter-group">
                  <Form.Select className="bg-light filter-input">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Black</option>
                  </Form.Select>
                </InputGroup>
              </Col>

              {/* Add Black Patient Button */}
              <Col className="text-end">
                <SearchBar />
              </Col>
            </Row>

            <Table responsive hover className="custom-table">
              <thead>
                <tr>
                  <th>
                    <Form.Check />
                  </th>
                  <th>ID</th>
                  <th>National ID</th>
                  <th>Account ID</th>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Username</th>
                  <th>Status</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(10)].map((_, idx) => (
                  <tr key={idx}>
                    <td>
                      <Form.Check />
                    </td>
                    <td>61165</td>
                    <td>P564411</td>
                    <td>Hakim</td>
                    <td>+235-8566-8796</td>
                    <td>alex001@gmail.com</td>
                    <td>alex001</td>
                    <td>
                      <Button variant="dark" size="sm">
                        Block
                      </Button>
                    </td>
                    <td>21</td>
                    <td>Female</td>
                    <td>
                      <Button variant="dark" size="sm">
                        Block
                      </Button>
                    </td>
                    <td>
                      <span className="three-dots-icon">
                        <FaEllipsisH />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>

            <nav>
              <ul className="pagination justify-content-end">
                <li className="page-item">
                  <Link className="page-link" to="#">
                    Previous
                  </Link>
                </li>
                <li className="page-item">
                  <Link className="page-link" to="#">
                    1
                  </Link>
                </li>
                <li className="page-item">
                  <Link className="page-link" to="#">
                    2
                  </Link>
                </li>
                <li className="page-item">
                  <Link className="page-link" to="#">
                    Next
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </Container>
      </div>
    </div>
  );
};

export default Dashboard;
