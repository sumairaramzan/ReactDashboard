import React from "react";
import {
  FaFileAlt,
  FaFilePdf,
  FaFileArchive,
  FaFileWord,
  FaFilePowerpoint,
} from "react-icons/fa";
import { Card as BootstrapCard, Button } from "react-bootstrap";

// Function to determine file icon based on file extension
const getFileIcon = (fileName) => {
  const ext = fileName.split(".").pop().toLowerCase();

  switch (ext) {
    case "pdf":
      return <FaFilePdf className="fs-3" style={{ color: "#188F97" }} />;
    case "zip":
    case "rar":
      return <FaFileArchive className="fs-3" style={{ color: "#188F97" }} />;
    case "doc":
    case "docx":
      return <FaFileWord className="fs-3" style={{ color: "#188F97" }} />;
    case "ppt":
    case "pptx":
      return <FaFilePowerpoint className="fs-3" style={{ color: "#188F97" }} />;
    default:
      return <FaFileAlt className="fs-3" style={{ color: "#188F97" }} />;
  }
};

const Card = ({ file }) => {
  if (!file) {
    return <p className="text-danger">No file data available!</p>;
  }

  return (
    <BootstrapCard className="shadow-sm border-0 rounded-lg p-3 h-100 d-flex flex-column">
      {/* Top Section */}
      <div className="d-flex justify-content-between align-items-center">
        {getFileIcon(file.name)}
        <button className="btn-pink px-3 py-1 rounded text-nowrap">
          {file.status}
        </button>
      </div>

      {/* Card Content */}
      <BootstrapCard.Body className="px-0 d-flex flex-column flex-grow-1">
        <BootstrapCard.Title className="mt-2 mb-1 text-truncate">
          {file.name}
        </BootstrapCard.Title>
        <BootstrapCard.Subtitle className="text-muted small">
          {file.size}
        </BootstrapCard.Subtitle>

        {/* Profile Section */}
        <div className="d-flex align-items-center mt-3">
          <img
            src={file.image}
            alt={file.uploadedBy}
            className="rounded-circle me-2"
            style={{ width: "40px", height: "40px" }}
          />
          <div className="text-truncate">
            <p className="mb-0 fw-medium">Uploaded by: {file.uploadedBy}</p>
            <p className="text-muted small mb-0">{file.uploadDate}</p>
          </div>
        </div>

        {/* Buttons - Responsive Layout */}
        <div className="mt-auto pt-3">
          <div className="d-flex flex-wrap justify-content-between gap-2">
            <Button
              className="flex-grow-1 py-2 text-center"
              style={{ backgroundColor: "#188F97", border: "none" ,} }
            >
              View
            </Button>
            <Button
              className="flex-grow-1 py-2 text-center"
              variant="outline-primary"
              style={{ borderColor: "#188F97", color: "#188F97" }}
            >
              Download
            </Button>
            <Button
              className="flex-grow-1 py-2 text-center"
              variant="outline-primary"
              style={{ borderColor: "#188F97", color: "#188F97" }}
            >
              Delete
            </Button>
          </div>
        </div>
      </BootstrapCard.Body>
    </BootstrapCard>
  );
};

export default Card;
