import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../App.css";
import {
  Navbar,
  Nav,
  Container,
  Row,
  Col,
  Button,
  Tabs,
  Tab,
} from "react-bootstrap";
import {
  FaUser,
  FaFilePrescription,
  FaConciergeBell,
  FaBook,
  FaBell,
  FaPlus,
  FaWhatsapp,
  FaHouseUser,
  FaCalendar,
  FaRegFilePowerpoint,
  FaBars,
  FaTimes,
} from "react-icons/fa";
import SearchBar from "./SearchBar/SearchBar";
import Card from "./Card/Card";
import img1 from "../assets/Profile.png";

const Dashboard = () => {
  const [key, setKey] = useState("approved");
  const files = [
    {
      id: 1,
      name: "Project API Documentation.docx",
      size: "2.45 MB",
      uploadedBy: "John Doe",
      uploadDate: "10/12/2024",
      status: "New", // Status can be New, Reviewed, Approved, etc.
      image: "https://randomuser.me/api/portraits/men/1.jpg",
    },
    {
      id: 2,
      name: "UI Design Guidelines.pdf",
      size: "1.89 MB",
      uploadedBy: "Jane Smith",
      uploadDate: "08/11/2024",
      status: "Reviewed", // Status change
      image: "https://randomuser.me/api/portraits/women/2.jpg",
    },
    {
      id: 3,
      name: "Marketing Strategy 2025.pptx",
      size: "3.2 MB",
      uploadedBy: "Michael Johnson",
      uploadDate: "05/09/2024",
      status: "Approved", // New Status
      image: "https://randomuser.me/api/portraits/men/3.jpg",
    },
    {
      id: 4,
      name: "Marketing Strategy 2025.pptx",
      size: "3.2 MB",
      uploadedBy: "Michael Johnson",
      uploadDate: "05/09/2024",
      status: "Approved", // New Status
      image: "https://randomuser.me/api/portraits/men/3.jpg",
    },
    {
      id: 5,
      name: "Marketing Strategy 2025.pptx",
      size: "3.2 MB",
      uploadedBy: "Michael Johnson",
      uploadDate: "05/09/2024",
      status: "Approved", // New Status
      image: "https://randomuser.me/api/portraits/men/3.jpg",
    },
    {
      id: 6,
      name: "Marketing Strategy 2025.pptx",
      size: "3.2 MB",
      uploadedBy: "Michael Johnson",
      uploadDate: "05/09/2024",
      status: "Approved", // New Status
      image: "https://randomuser.me/api/portraits/men/3.jpg",
    },
  ];

  const profileImages = [img1, img1, img1, img1, img1];
  const [collapsed, setCollapsed] = useState(false); 

  return (
    <div className={`dashboard-container ${collapsed ? "collapsed" : ""}`}>
      <div className={`sidebar bg-white shadow-sm ${collapsed ? "collapsed" : ""}`}>
       
        <ul className="list-unstyled px-2">
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaHouseUser className="me-2" /> {!collapsed && "Dashboard"}
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaFilePrescription className="me-2" /> {!collapsed && "Clients"}
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaConciergeBell className="me-2" /> {!collapsed && "Proposals"}
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaUser className="me-2" /> {!collapsed && "Projects"}
            </Link>
          </li>

          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaBook className="me-2" /> {!collapsed && "Team"}
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaCalendar className="me-2" /> {!collapsed && "Calendar"}
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="nav-link px-3 py-2 d-flex align-items-center"
            >
              <FaRegFilePowerpoint className="me-2" /> {!collapsed && "Report"}
            </Link>
          </li>
        </ul>
      </div>

      <div className="main-content">

        
      <Navbar bg="white" expand="lg" className="border-bottom mb-4">
      <Container fluid>
      <Button variant="light" className="toggle-btn" onClick={() => setCollapsed(!collapsed)}>
              {collapsed ? <FaBars size={20} /> : <FaTimes size={20} />}
            </Button>
        {/* Left Side - Brand & Profile Images */}
        <Navbar.Brand className="d-flex align-items-center">
          <h2 className="mb-0">IDEVO Solutions</h2>
          <div className="d-flex ms-2">
            {profileImages.map((img, index) => (
              <img
                key={index}
                src={img}
                alt={`Profile ${index + 1}`}
                className="rounded-circle border"
                style={{
                  width: "30px",
                  height: "30px",
                  marginLeft: index === 0 ? "0" : "-10px",
                  border: "2px solid white",
                }}
              />
            ))}
          </div>
        </Navbar.Brand>

        {/* Responsive Navbar Toggle Button */}
        <Navbar.Toggle aria-controls="navbar-content">
          <FaBars />
        </Navbar.Toggle>

        {/* Collapsible Navbar Content */}
        <Navbar.Collapse id="navbar-content">
          <Nav className="ms-auto align-items-center gap-3">
            {/* SearchBar Component */}
            <Nav.Link href="#" className="position-relative">
              <SearchBar />
            </Nav.Link>

            <Nav.Link href="#" className="notification-link position-relative d-flex gap-2">
              <FaBell size={20} />
              <FaWhatsapp size={20} />
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>

    <Container fluid>
      <Tabs
        activeKey={key}
        onSelect={(k) => setKey(k)}
        className="mb-3 custom-tabs"
      >
        <Tab eventKey="all" title="Overview">
          <Row className="g-4">
            {files.map((file) => (
              <Col key={file.id} xs={12} sm={6} md={4}>
                <Card file={file} />
              </Col>
            ))}
          </Row>
        </Tab>

        <Tab eventKey="new" title="Onboard">
          <Row className="g-4">
            {files
              .filter((file) => file.status === "New")
              .map((file) => (
                <Col key={file.id} xs={12} sm={6} md={4}>
                  <Card file={file} />
                </Col>
              ))}
          </Row>
        </Tab>

        <Tab eventKey="reviewed" title="Milestones">
          <Row className="g-4">
            {files
              .filter((file) => file.status === "Reviewed")
              .map((file) => (
                <Col key={file.id} xs={12} sm={6} md={4}>
                  <Card file={file} />
                </Col>
              ))}
          </Row>
        </Tab>

        <Tab eventKey="approved" title="Deliverables/Documents">
          <div className="d-flex flex-wrap justify-content-between align-items-center mb-3">
            <h4 className="mb-0">Deliverables/Documents</h4>

            <div className="d-flex flex-wrap gap-2 mt-2 mt-md-0">
              <Button
                variant="outline-primary"
                style={{ borderColor: "#188F97", color: "#188F97" }}
              >
                Grid View
              </Button>
              <Button className="rounded btn_color">
                <FaPlus /> Add Documents
              </Button>
            </div>
          </div>

          <Row className="g-4">
            {files.map((file) => (
              <Col key={file.id} xs={12} sm={6} md={4}>
                <Card file={file} />
              </Col>
            ))}
          </Row>
        </Tab>

        <Tab eventKey="Calender" title="Calendar">
          <Row className="g-4">
            {files
              .filter((file) => file.status === "Calender")
              .map((file) => (
                <Col key={file.id} xs={12} sm={6} md={4}>
                  <Card file={file} />
                </Col>
              ))}
          </Row>
        </Tab>

        <Tab eventKey="Messages" title="Messages">
          <Row className="g-4">
            {files
              .filter((file) => file.status === "Messages")
              .map((file) => (
                <Col key={file.id} xs={12} sm={6} md={4}>
                  <Card file={file} />
                </Col>
              ))}
          </Row>
        </Tab>
      </Tabs>
    </Container>
      </div>
    </div>
  );
};

export default Dashboard;
