import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, Link } from "react-router-dom";
import { registerUser } from "../../redux/slices/authSlice";
import bgImage from "../../assets/Pagebg.png"; // Importing local image

const Register = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { successMessage, loading, error } = useSelector(
    (state) => state.auth
  );

  useEffect(() => {
    if (successMessage) {
      alert(successMessage);
      navigate("/login");
    }
  }, [successMessage, navigate]);

  const handleRegister = (e) => {
    e.preventDefault();
    dispatch(registerUser({ email, password }));
  };

  return (
    <div
      className="container-fluid d-flex justify-content-center align-items-center vh-100"
      style={{
        backgroundImage: `url(${bgImage})`, // Using imported local image
        backgroundSize: "cover",
        backgroundPosition: "center",
        position: "relative",
      }}
    >
      {/* Overlay for low opacity effect */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0, 0, 0, 0.5)", // Black overlay with low opacity
          zIndex: 1,
        }}
      ></div>

      {/* Card Content */}
      <div
        className="card shadow-lg p-4 rounded-4"
        style={{
          maxWidth: "400px",
          width: "100%",
          zIndex: 2, // Bring card above overlay
          background: "rgba(255, 255, 255, 0.85)", // Slightly transparent card background
          backdropFilter: "blur(10px)", // Blur effect behind the card
        }}
      >
        <h3 className="text-center mb-4">Create an Account</h3>
        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              type="email"
              className="form-control rounded-3"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input
              type="password"
              className="form-control rounded-3"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="btn btn-primary w-100 rounded-3"
            disabled={loading}
          >
            {loading ? "Registering..." : "Register"}
          </button>
          {error && <div className="alert alert-danger mt-3">{error}</div>}
        </form>
        <div className="mt-3 text-center">
          Already have an account? <Link to="/login">Login here</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
